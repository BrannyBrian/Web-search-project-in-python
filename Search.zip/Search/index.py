import os
import pickle
import sys
import string
import nltk
import re
import nltk.stem as ns

nltk.download('wordnet', quiet=True)
nltk.download('omw-1.4', quiet=True)
nltk.download('punkt', quiet=True)

def merge(a, b):
    ret = []
    i = j = 0
    while len(a) >= i + 1 and len(b) >= j + 1:
        if a[i] <= b[j]:
            ret.append(a[i])
            i += 1
        else:
            ret.append(b[j])
            j += 1
    if len(a) > i:
        ret += a[i:]
    if len(b) > j:
        ret += b[j:]
    return ret

def search_word(query, index_dict):
    query = query.lower()
    lemmatizer = ns.WordNetLemmatizer()
    query = re.sub('[{}]'.format(re.escape(string.punctuation)), ' ', query)
    query = re.sub(' +', ' ', query)
    tokens = nltk.word_tokenize(query)
    lemmatized_query = [lemmatizer.lemmatize(token, pos='n') for token in tokens]
    
    results = []
    for term in lemmatized_query:
        if term in index_dict:
            results.append(index_dict[term])
    
    if not results:
        return []
    
    final_result = results[0]
    for result in results[1:]:
        final_result = merge(final_result, result)
    
    return final_result

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python search.py <search_query>")
        sys.exit(1)

    # Replace with the path to your index file
    index_file = 'C:/Users/Branny Brian/Desktop/Search/output/index'
    
    if not os.path.exists(index_file):
        print(f"Index file not found at {index_file}")
        sys.exit(1)

    with open(index_file, 'rb') as f:
        index_dict = pickle.load(f)

    search_query = ' '.join(sys.argv[1:])
    
    results = search_word(search_query, index_dict)

    if not results:
        print("No results found for the query.")
    else:
        print("Results found for the query:")
        for doc_id in results[0]:
            print(f"Document ID: {doc_id}")
